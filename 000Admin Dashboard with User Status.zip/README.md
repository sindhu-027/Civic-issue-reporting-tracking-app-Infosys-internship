
  # Admin Dashboard with User Status

  This is a code bundle for Admin Dashboard with User Status. The original project is available at https://www.figma.com/design/7yFPRyTcrs5tlQyRITA0To/Admin-Dashboard-with-User-Status.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  