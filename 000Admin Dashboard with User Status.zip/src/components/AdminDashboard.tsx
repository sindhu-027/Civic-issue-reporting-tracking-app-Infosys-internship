import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { OverviewSection } from "./OverviewSection";
import { ManageUsers } from "./ManageUsers";
import { ViewComplaints } from "./ViewComplaints";
import { Shield, User, LayoutDashboard, Users, FileText } from "lucide-react";
import { Button } from "./ui/button";

export function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("admin");

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="flex items-center justify-between px-6 py-3">
          <div className="flex items-center gap-8">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <Shield className="w-6 h-6 text-blue-600" />
              <span className="text-gray-900">CleanStreet</span>
            </div>

            {/* Navigation */}
            <nav className="flex items-center gap-1">
              <button
                onClick={() => setActiveTab("dashboard")}
                className={`px-4 py-2 text-sm transition-colors ${
                  activeTab === "dashboard"
                    ? "text-gray-900"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Dashboard
              </button>
              <button
                onClick={() => setActiveTab("report")}
                className={`px-4 py-2 text-sm transition-colors ${
                  activeTab === "report"
                    ? "text-gray-900"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Report Issue
              </button>
              <button
                onClick={() => setActiveTab("admin")}
                className={`px-4 py-2 text-sm transition-colors ${
                  activeTab === "admin"
                    ? "text-gray-900"
                    : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Admin
              </button>
            </nav>
          </div>

          {/* User Section */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <User className="w-5 h-5 text-gray-600" />
              <span className="text-sm text-gray-700">Username</span>
            </div>
            <Button variant="ghost" className="text-sm">
              Sign out
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {activeTab === "admin" && (
          <div>
            <div className="mb-8">
              <h2 className="text-gray-900 mb-2">Admin Dashboard</h2>
              <p className="text-gray-600">Overview and management tools</p>
            </div>

            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="overview" className="flex items-center gap-2">
                  <LayoutDashboard className="w-4 h-4" />
                  Overview
                </TabsTrigger>
                <TabsTrigger value="users" className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Manage Users
                </TabsTrigger>
                <TabsTrigger value="complaints" className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  View Complaints
                </TabsTrigger>
              </TabsList>

              <TabsContent value="overview">
                <OverviewSection />
              </TabsContent>

              <TabsContent value="users">
                <ManageUsers />
              </TabsContent>

              <TabsContent value="complaints">
                <ViewComplaints />
              </TabsContent>
            </Tabs>
          </div>
        )}

        {activeTab === "dashboard" && (
          <div className="text-center py-20">
            <p className="text-gray-500">Dashboard page coming soon...</p>
          </div>
        )}

        {activeTab === "report" && (
          <div className="text-center py-20">
            <p className="text-gray-500">Report Issue page coming soon...</p>
          </div>
        )}
      </main>
    </div>
  );
}
