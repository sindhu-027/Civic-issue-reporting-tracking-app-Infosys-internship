import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Edit, Trash2 } from "lucide-react";

type UserRole = "user" | "volunteer" | "admin" | "pending";

interface User {
  id: string;
  name: string;
  email: string;
  location: string;
  role: UserRole;
  joined: string;
}

const initialUsers: User[] = [
  {
    id: "1",
    name: "user3",
    email: "user3@gmail.com",
    location: "Mysore",
    role: "user",
    joined: "Oct 24, 2025, 05:20 PM",
  },
  {
    id: "2",
    name: "Vadiraj Joshi",
    email: "vadirajjoshi@gmail.com",
    location: "Hosapete",
    role: "volunteer",
    joined: "Oct 20, 2025, 07:40 PM",
  },
  {
    id: "3",
    name: "Vadiraj",
    email: "vadiraj@gmail.com",
    location: "Tumkur",
    role: "admin",
    joined: "Oct 18, 2025, 02:59 PM",
  },
  {
    id: "4",
    name: "user2",
    email: "user2@gmail.com",
    location: "Bengaluru",
    role: "user",
    joined: "Oct 16, 2025, 06:42 PM",
  },
  {
    id: "5",
    name: "user1",
    email: "user1@gmail.com",
    location: "Tumkuru",
    role: "user",
    joined: "Oct 15, 2025, 10:53 PM",
  },
];

export function ManageUsers() {
  const [users, setUsers] = useState<User[]>(initialUsers);

  const handleRoleChange = (userId: string, newRole: UserRole) => {
    setUsers(users.map(user => 
      user.id === userId ? { ...user, role: newRole } : user
    ));
  };

  const getRoleBadgeVariant = (role: UserRole) => {
    switch (role) {
      case "admin":
        return "destructive";
      case "volunteer":
        return "default";
      case "user":
        return "secondary";
      case "pending":
        return "outline";
      default:
        return "secondary";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>User Management</CardTitle>
        <CardDescription>Manage user roles and permissions</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>{user.name}</TableCell>
                  <TableCell className="text-gray-600">{user.email}</TableCell>
                  <TableCell className="text-gray-600">{user.location}</TableCell>
                  <TableCell>
                    <Select
                      value={user.role}
                      onValueChange={(value) => handleRoleChange(user.id, value as UserRole)}
                    >
                      <SelectTrigger className="w-[130px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="user">User</SelectItem>
                        <SelectItem value="volunteer">Volunteer</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="text-gray-600 text-sm">{user.joined}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="ghost" size="icon">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
