import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Users, FileText, CheckCircle, AlertCircle } from "lucide-react";

const userGrowthData = [
  { month: "Jan", users: 45, volunteers: 12 },
  { month: "Feb", users: 52, volunteers: 15 },
  { month: "Mar", users: 68, volunteers: 18 },
  { month: "Apr", users: 78, volunteers: 22 },
  { month: "May", users: 95, volunteers: 28 },
  { month: "Jun", users: 112, volunteers: 35 },
];

const complaintStatusData = [
  { name: "Pending", value: 15, color: "#f59e0b" },
  { name: "On Progress", value: 22, color: "#3b82f6" },
  { name: "Resolved", value: 58, color: "#10b981" },
  { name: "Issue", value: 5, color: "#ef4444" },
];

const monthlyComplaints = [
  { month: "Jan", complaints: 25 },
  { month: "Feb", complaints: 32 },
  { month: "Mar", complaints: 28 },
  { month: "Apr", complaints: 45 },
  { month: "May", complaints: 38 },
  { month: "Jun", complaints: 42 },
];

export function OverviewSection() {
  const totalUsers = 112;
  const totalVolunteers = 35;
  const totalComplaints = 100;
  const resolvedComplaints = 58;

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm">Total Users</CardTitle>
            <Users className="w-4 h-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-gray-900">{totalUsers}</div>
            <p className="text-xs text-gray-500 mt-1">+15% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm">Volunteers</CardTitle>
            <Users className="w-4 h-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-gray-900">{totalVolunteers}</div>
            <p className="text-xs text-gray-500 mt-1">+25% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm">Total Complaints</CardTitle>
            <FileText className="w-4 h-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-gray-900">{totalComplaints}</div>
            <p className="text-xs text-gray-500 mt-1">This month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm">Resolved</CardTitle>
            <CheckCircle className="w-4 h-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl text-gray-900">{resolvedComplaints}</div>
            <p className="text-xs text-gray-500 mt-1">{Math.round((resolvedComplaints / totalComplaints) * 100)}% resolution rate</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Growth Chart */}
        <Card>
          <CardHeader>
            <CardTitle>User Growth</CardTitle>
            <CardDescription>Monthly users and volunteers registration</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={userGrowthData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="users" fill="#3b82f6" name="Users" />
                <Bar dataKey="volunteers" fill="#10b981" name="Volunteers" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Complaint Status Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Complaint Status Distribution</CardTitle>
            <CardDescription>Current status of all complaints</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={complaintStatusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {complaintStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Monthly Complaints Trend */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Monthly Complaints Trend</CardTitle>
            <CardDescription>Number of complaints reported each month</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyComplaints}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="complaints" stroke="#3b82f6" strokeWidth={2} name="Complaints" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
