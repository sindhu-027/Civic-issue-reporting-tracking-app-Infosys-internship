import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Eye, MoreHorizontal } from "lucide-react";

type ComplaintStatus = "pending" | "on progress" | "resolved" | "issue";

interface Complaint {
  id: string;
  title: string;
  reportedBy: string;
  type: string;
  status: ComplaintStatus;
  assignedTo: string;
  date: string;
}

const initialComplaints: Complaint[] = [
  {
    id: "1",
    title: "water leakage",
    reportedBy: "user1",
    type: "water leakage",
    status: "on progress",
    assignedTo: "volunteer3",
    date: "Oct 29, 2025, 06:29 PM",
  },
  {
    id: "2",
    title: "garbage not cleared",
    reportedBy: "Vadiraj Joshi",
    type: "Garbage",
    status: "resolved",
    assignedTo: "volunteer2",
    date: "Oct 29, 2025, 06:29 PM",
  },
  {
    id: "3",
    title: "pothole in my road",
    reportedBy: "Vadiraj Joshi",
    type: "Road Damage",
    status: "pending",
    assignedTo: "Unassigned",
    date: "Oct 27, 2025, 06:29 PM",
  },
  {
    id: "4",
    title: "Street light not working",
    reportedBy: "user2",
    type: "Electricity",
    status: "on progress",
    assignedTo: "volunteer1",
    date: "Oct 26, 2025, 03:15 PM",
  },
  {
    id: "5",
    title: "Broken drainage pipe",
    reportedBy: "user3",
    type: "Drainage",
    status: "issue",
    assignedTo: "volunteer2",
    date: "Oct 25, 2025, 11:20 AM",
  },
  {
    id: "6",
    title: "Illegal parking",
    reportedBy: "Vadiraj",
    type: "Parking",
    status: "resolved",
    assignedTo: "volunteer3",
    date: "Oct 24, 2025, 09:45 AM",
  },
];

export function ViewComplaints() {
  const [complaints, setComplaints] = useState<Complaint[]>(initialComplaints);

  const handleStatusChange = (complaintId: string, newStatus: ComplaintStatus) => {
    setComplaints(complaints.map(complaint => 
      complaint.id === complaintId ? { ...complaint, status: newStatus } : complaint
    ));
  };

  const getStatusBadgeVariant = (status: ComplaintStatus) => {
    switch (status) {
      case "resolved":
        return "default";
      case "on progress":
        return "secondary";
      case "pending":
        return "outline";
      case "issue":
        return "destructive";
      default:
        return "outline";
    }
  };

  const getStatusColor = (status: ComplaintStatus) => {
    switch (status) {
      case "resolved":
        return "text-green-600 bg-green-50";
      case "on progress":
        return "text-blue-600 bg-blue-50";
      case "pending":
        return "text-amber-600 bg-amber-50";
      case "issue":
        return "text-red-600 bg-red-50";
      default:
        return "text-gray-600 bg-gray-50";
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>All Complaints</CardTitle>
        <CardDescription>View and manage all reported complaints</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Reported By</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Assigned To</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {complaints.map((complaint) => (
                <TableRow key={complaint.id}>
                  <TableCell>{complaint.title}</TableCell>
                  <TableCell className="text-gray-600">{complaint.reportedBy}</TableCell>
                  <TableCell className="text-gray-600">{complaint.type}</TableCell>
                  <TableCell>
                    <Select
                      value={complaint.status}
                      onValueChange={(value) => handleStatusChange(complaint.id, value as ComplaintStatus)}
                    >
                      <SelectTrigger className={`w-[140px] border-none ${getStatusColor(complaint.status)}`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="on progress">On Progress</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                        <SelectItem value="issue">Issue</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="text-gray-600">{complaint.assignedTo}</TableCell>
                  <TableCell className="text-gray-600 text-sm">{complaint.date}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="ghost" size="icon">
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
